﻿using System;
using System.Windows.Forms;

namespace SistemaSolar
{
    public partial class FormSistemaSolar : Form
    {
        public FormSistemaSolar()
        {
                InitializeComponent();
        }

        private void btnRotarPlaneta_Click(object sender, EventArgs e)
        {

        }

        private void btnOrbitarSatelite_Click(object sender, EventArgs e)
        {

        }

        private void btnSatelite_Click(object sender, EventArgs e)
        {

        }
    }
}
